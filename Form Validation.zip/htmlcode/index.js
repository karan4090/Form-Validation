// DOM Elements
const form = document.getElementById("registration-form");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const nameError = document.getElementById("name-error");
const emailError = document.getElementById("email-error");
const passwordError = document.getElementById("password-error");

// Validate Name
function validateName() {
    if (nameInput.value.trim() === "") {
        nameError.style.display = "block";
        nameInput.style.border = "1px solid red";
        return false;
    } else {
        nameError.style.display = "none";
        nameInput.style.border = "1px solid #ccc";
        return true;
    }
}

// Validate Email
function validateEmail() {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Basic email validation regex
    if (!emailRegex.test(emailInput.value.trim())) {
        emailError.style.display = "block";
        emailInput.style.border = "1px solid red";
        return false;
    } else {
        emailError.style.display = "none";
        emailInput.style.border = "1px solid #ccc";
        return true;
    }
}

// Validate Password
function validatePassword() {
    if (passwordInput.value.trim().length < 8) {
        passwordError.style.display = "block";
        passwordInput.style.border = "1px solid red";
        return false;
    } else {
        passwordError.style.display = "none";
        passwordInput.style.border = "1px solid #ccc";
        return true;
    }
}

// Attach Event Listeners for Real-Time Validation
nameInput.addEventListener("input", validateName);
emailInput.addEventListener("input", validateEmail);
passwordInput.addEventListener("input", validatePassword);

// Prevent Form Submission if Validation Fails
form.addEventListener("submit", (event) => {
    const isNameValid = validateName();
    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();

    if (!isNameValid || !isEmailValid || !isPasswordValid) {
        event.preventDefault(); // Stop form submission
        alert("Please fix the errors in the form before submitting.");
    }
});
